package com.pengrad.telegrambot.model.request;

import java.io.Serializable;

/**
 * Stas Parshin
 * 04 June 2019
 */
public class CallbackGame implements Serializable {
    private final static long serialVersionUID = 0L;
}
