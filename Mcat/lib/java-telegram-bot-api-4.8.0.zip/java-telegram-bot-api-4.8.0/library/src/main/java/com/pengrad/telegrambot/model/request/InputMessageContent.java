package com.pengrad.telegrambot.model.request;

import java.io.Serializable;

/**
 * Stas Parshin
 * 06 May 2016
 */
public abstract class InputMessageContent implements Serializable {
    private final static long serialVersionUID = 0L;
}
