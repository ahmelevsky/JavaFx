package com.pengrad.telegrambot.passport;

/**
 * Stas Parshin
 * 02 August 2018
 * <p>
 * Decrypted data from the data field in EncryptedPassportElement.
 * Can be one of the following types: PersonalDetails, IdDocumentData, ResidentialAddress
 */
abstract public class DecryptedData {
}
