package com.pengrad.telegrambot.model.request;

/**
 * stas
 * 10/21/15.
 */
public enum ParseMode {
    Markdown, MarkdownV2, HTML
}
